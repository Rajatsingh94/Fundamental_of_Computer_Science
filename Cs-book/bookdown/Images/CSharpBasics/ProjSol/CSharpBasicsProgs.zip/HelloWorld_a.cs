// Prints the string HelloWorld to the console  
using System; 
namespace CSFund1.Chap1.HelloWorldApp
{ 
class HelloWorld  
{ 
public static void Main() 
{ 
Console.WriteLine ("Hello World");
} 
}   
}
